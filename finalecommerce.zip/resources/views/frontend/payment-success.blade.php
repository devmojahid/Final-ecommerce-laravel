<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payemnt Success</title>
</head>
<body>
    {{-- <h1>Hi {{ $pament->cus_name }}</h1>
    <h1>Email {{ $pament->cus_email }}</h1> --}}
    {{-- @foreach ($data as $paymentman)
        {{-- <h1>{{ $paymentman->cus_name }}</h1> --}}
        {{-- {{ dd($paymentman) }} --}}
        {{ dd($data) }}
</html>
