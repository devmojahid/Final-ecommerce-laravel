@include("frontend.header")
<main class="main">
    @yield('content')
</main>
@include("frontend.footer")
