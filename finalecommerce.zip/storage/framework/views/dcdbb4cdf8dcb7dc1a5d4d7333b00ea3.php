<?php $__env->startSection('admin_content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Product/</span> Brands</h4>

        <!-- Basic Layout -->
        <div class="row">
            <div class="col-xl">
                <div class="card">
                    <div class="table-responsive text-nowrap">
                        <table class="table">
                            <thead class="table-light">
                                <tr>
                                    <th>SI.</th>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Tag</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <?php echo e($key + 1); ?> </td>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <?php echo e($blog->title); ?> </td>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($blog->category_id); ?></td>
                                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo e($blog->tag_id); ?></td>
                                        <td><span class="badge bg-label-primary me-1"> <?php echo e($blog->status); ?></span> </td>
                                        <td>
                                            <div class="dropdown">
                                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                    data-bs-toggle="dropdown">
                                                    <i class="bx bx-dots-vertical-rounded"></i>
                                                </button>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="<?php echo e(route('blog.edit', $blog->slug)); ?>"
                                                        href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('blog.delete', $blog->slug)); ?>"><i
                                                            class="bx bx-trash me-1"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-xl">
                <form action="<?php echo e(route('blog.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card mb-4">
                        <div class="card-body">

                            <div class="mb-3">
                                <label class="form-label" for="basic-default-fullname">Title</label>
                                <input type="text" name="title" class="form-control" id="basic-default-fullname"
                                    placeholder="Somthing Title">
                            </div>

                            <div class="mb-3">
                                <label for="formFile" class="form-label">Blog Image</label>
                                <input class="form-control" name="image" type="file" id="formFile">
                            </div>

                            

                            <div class="row mb-3">
                                <label for="defaultInput" class="form-label">Category</label>
                                <div class="col-sm-12">
                                    <select name="category_id" id="defaultSelect" class="form-select" >
                                        <option value="">Category select</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>


                            
                            <div class="row mb-3">
                                <label for="defaultInput" class="form-label">Tag</label>
                                <div class="col-sm-12">
                                    <select name="tag_id" id="defaultSelect" class="form-select">
                                        <option value="">Tag select</option>
                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label" for="basic-default-message">Content</label>
                                <textarea id="basic-default-message" name="content" class="tinymce-editor form-control" placeholder="summary"></textarea>
                            </div>


                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">SEO Meta Tags</h5>
                        </div>
                        <div class="card-body">
                            
                            <div class="row mb-3">
                                <label class="form-label" for="basic-default-name">Meta Title</label>
                                <div class="col-sm-12">
                                    <input class="form-control" name="meta_title" type="text" placeholder="Meta Title"
                                        id="html5-number-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="form-label" for="basic-default-name">Meta Description</label>
                                <div class="col-sm-12">
                                    <textarea class="tinymce-editor form-control" rows="10" name="meta_description" type="text" placeholder="Meta Description"
                                        id="html5-number-input"></textarea>
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="form-label" for="basic-default-name">Meta Keywords</label>
                                <div class="col-sm-12">
                                    <input class="form-control" name="meta_keywords" type="text"
                                        placeholder="Meta Keywords" id="html5-number-input">
                                </div>
                            </div>

                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
<script type="text/javascript">
    tinymce.init({
    selector: 'textarea.tinymce-editor',
    height: 400,
    menubar: true,
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.parsial.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lvnpp\Final-Ecomm\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>