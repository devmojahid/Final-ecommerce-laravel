<?php echo $__env->make("frontend.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="main">
    <?php echo $__env->yieldContent('content'); ?>
</main>
<?php echo $__env->make("frontend.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\lvnpp\Final-Ecomm\resources\views/frontend/app.blade.php ENDPATH**/ ?>