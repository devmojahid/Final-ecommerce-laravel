<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8" />
    <title>Final Ecomm</title>
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta property="og:title" content="" />
    <meta property="og:type" content="" />
    <meta property="og:url" content="" />
    <meta property="og:image" content="" />
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('storage/'.get_settings('favicon'))); ?>" />
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/plugins/animate.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/main.css?v=5.6" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendors/toastr.min.css" />

</head>

<body>
    <header class="header-area header-style-1 header-height-2">
        <div class="mobile-promotion">
            <span>Grand opening, <strong>up to 15%</strong> off all items. Only <strong>3 days</strong> left</span>
        </div>
        <div class="header-top header-top-ptb-1 d-none d-lg-block">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-3 col-lg-4">
                        <div class="header-info">
                            <ul>
                                <li><a href="<?php echo e(route("user.account")); ?>">Account</a></li>
                                <li><a href="<?php echo e(route('wishlist-page')); ?>">Wishlist</a></li>
                                <li><a href="<?php echo e(route("user.account")); ?>">Order</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-4">

                    </div>
                    <div class="col-xl-3 col-lg-4">
                        <div class="header-info header-info-right">
                            <ul>
                                <li>Need help? Call Us: <strong class="text-brand"> <?php echo e(get_settings('phone')); ?> </strong></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
            $categories = App\Models\Category::where('status', 1)->take(10)->get();
        ?>
        <div class="header-middle header-middle-ptb-1 d-none d-lg-block">
            <div class="container">
                <div class="header-wrap">
                    <div class="logo logo-width-1">
                        <a href="<?php echo e(route("home-page")); ?>"><img width="100%" height="100%" src="<?php echo e(asset('storage/'.get_settings('logo'))); ?>"
                                alt="logo" /></a>
                    </div>
                    <div class="header-right">
                        <div class="search-style-2">
                            <form action="#">
                                <select class="select-active">
                                    <option>All Categories</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($category->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="text" placeholder="Search for items..." />
                            </form>
                        </div>
                        <div class="header-action-right">
                            <div class="header-action-2">
                                <div class="header-action-icon-2">
                                    <a href="<?php echo e(route('wishlist-page')); ?>">
                                        <img class="svgInject" alt="Nest"
                                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-heart.svg" />
                                        <span class="pro-count blue">6</span>
                                    </a>
                                    <a href="<?php echo e(route('wishlist-page')); ?>"><span class="lable">Wishlist</span></a>
                                </div>
                                <?php
                                $carts = App\Models\Cart::with("product")->where('user_ip', request()->ip())->get();
                                $carts_count = count($carts);
                                $total = 0;
                                ?>
                                <div class="header-action-icon-2">
                                    <a class="mini-cart-icon" href="<?php echo e(route("cart-page")); ?>">
                                        <img alt="Nest"
                                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-cart.svg" />
                                        <span class="pro-count blue"><?php echo e($carts_count); ?></span>
                                    </a>
                                    <a href="<?php echo e(route("cart-page")); ?>"><span class="lable">Cart</span></a>
                                    <div class="cart-dropdown-wrap cart-dropdown-hm2">
                                        <ul>

                                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                            <li>
                                                <div class="shopping-cart-img">
                                                    <a href="<?php echo e($cart->product->slug); ?>"><img alt="Nest"
                                                            src="<?php echo e(asset('storage/'.$cart->product->thumbnail)); ?>" /></a>
                                                </div>
                                                <div class="shopping-cart-title">
                                                    <h4><a href="<?php echo e($cart->product->slug); ?>"><?php echo e($cart->product->name); ?></a></h4>
                                                    <h4><span>1 × </span><?php echo e($cart->product->price); ?></h4>
                                                </div>
                                                <div class="shopping-cart-delete">
                                                    <a href="<?php echo e(route("cart.item.delete",$cart->id)); ?>"><i class="fi-rs-cross-small"></i></a>
                                                </div>
                                            </li>

                                            <?php
                                                $total = $total + $cart->product->price;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="shopping-cart-footer">
                                            <div class="shopping-cart-total">
                                                <h4>Total <span>$<?php echo e($total); ?></span></h4>
                                            </div>
                                            <div class="shopping-cart-button">
                                                <a href="<?php echo e(route('cart-page')); ?>" class="outline">View cart</a>
                                                <a href="<?php echo e(route('checkout-page')); ?>">Checkout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="header-action-icon-2">
                                    <a href="page-account.html">
                                        <img class="svgInject" alt="Nest"
                                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-user.svg" />
                                    </a>
                                    <a href="page-account.html"><span class="lable ml-0">Account</span></a>
                                    <div class="cart-dropdown-wrap cart-dropdown-hm2 account-dropdown">
                                        <ul>
                                            <?php if(!Auth::guard("web")->user()): ?>
                                            <li>
                                                <a href="<?php echo e(route('user.login')); ?>"><i class="fi fi-rs-user mr-10"></i>
                                                    Login</a>
                                            </li>
                                            <?php else: ?>
                                            <li>
                                                <a href="<?php echo e(route('user.account')); ?>"><i class="fi fi-rs-user mr-10"></i>My
                                                    Account</a>
                                            </li>
                                            <?php endif; ?>
                                            <li>
                                                <a href="<?php echo e(route("user.logout")); ?>"><i class="fi fi-rs-sign-out mr-10"></i>Sign
                                                    out</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom header-bottom-bg-color sticky-bar">
            <div class="container">
                <div class="header-wrap header-space-between position-relative">
                    <div class="logo logo-width-1 d-block d-lg-none">
                        <a href="<?php echo e(route("home-page")); ?>"><img src="<?php echo e(asset('storage/'.get_settings('logo'))); ?>"
                                alt="logo" /></a>
                    </div>
                    <div class="header-nav d-none d-lg-flex">
                        <div class="main-categori-wrap d-none d-lg-block">
                            <a class="categories-button-active" href="#">
                                <span class="fi-rs-apps"></span> <span class="et">All Categorys</span>
                                <i class="fi-rs-angle-down"></i>
                            </a>
                            <div class="categories-dropdown-wrap categories-dropdown-active-large font-heading">
                                <div class="d-flex categori-dropdown-inner">
                                    <ul>

                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($category->slug); ?>"> <img src="<?php echo e(asset("storage/".$category->photo)); ?>"
                                                    alt="" /><?php echo e($category->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="main-menu main-menu-padding-1 main-menu-lh-2 d-none d-lg-block font-heading">
                            <nav>
                                <ul>
                                    <li>
                                        <a class="active" href="<?php echo e(route("home-page")); ?>">Home </a>
                                    </li>
                                    <li>
                                        <a href="page-contact.html">Contact</a>
                                    </li>
                                    <li><a href="<?php echo e(route('shop-page')); ?>">Shop</a></li>
                                    <li><a href="<?php echo e(route('cart-page')); ?>">Cart</a></li>
                                    <li><a href="<?php echo e(route('blog.page')); ?>">Blog</a></li>
                                    <?php if(!Auth::guard("web")->user()): ?>
                                    <li><a href="<?php echo e(route("user.login")); ?>">Login</a></li>
                                    <li><a href="<?php echo e(route('user.register')); ?>">Register</a></li>
                                    <?php else: ?>
                                    <li><a href="<?php echo e(route("user.account")); ?>">My Account</a></li>
                                    <li><a href="<?php echo e(route("user.logout")); ?>">Logout</a></li>
                                    <?php endif; ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="header-action-icon-2 d-block d-lg-none">
                        <div class="burger-icon burger-icon-white">
                            <span class="burger-icon-top"></span>
                            <span class="burger-icon-mid"></span>
                            <span class="burger-icon-bottom"></span>
                        </div>
                    </div>
                    <div class="header-action-right d-block d-lg-none">
                        <div class="header-action-2">
                            <div class="header-action-icon-2">
                                <a href="<?php echo e(route('wishlist-page')); ?>">
                                    <img alt="Nest"
                                        src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-heart.svg" />
                                    <span class="pro-count white">4</span>
                                </a>
                            </div>

                            <div class="header-action-icon-2">
                                <a class="mini-cart-icon" href="<?php echo e(route("cart-page")); ?>">
                                    <img alt="Nest"
                                        src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-cart.svg" />
                                    <span class="pro-count white"><?php echo e($carts_count); ?></span>
                                </a>
                                <div class="cart-dropdown-wrap cart-dropdown-hm2">
                                    <ul>
                                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div class="shopping-cart-img">
                                                <a href="<?php echo e($cart->product->slug); ?>"><img alt="Nest"
                                                        src="<?php echo e(asset('storage/'.$cart->product->thumbnail)); ?>" /></a>
                                            </div>
                                            <div class="shopping-cart-title">
                                                <h4><a href="<?php echo e($cart->product->slug); ?>"><?php echo e($cart->product->name); ?></a></h4>
                                                <h3><span>1 × </span><?php echo e($cart->product->price); ?></h3>
                                            </div>
                                            <div class="shopping-cart-delete">
                                                <a href="<?php echo e(route("cart.item.delete",$cart->id)); ?>"><i class="fi-rs-cross-small"></i></a>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="shopping-cart-footer">
                                        <div class="shopping-cart-total">
                                            <h4>Total <span>$<?php echo e($total); ?></span></h4>
                                        </div>
                                        <div class="shopping-cart-button">
                                            <a href="<?php echo e(route("cart-page")); ?>">View cart</a>
                                            <a href="<?php echo e(route("checkout-page")); ?>">Checkout</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="mobile-header-active mobile-header-wrapper-style">
        <div class="mobile-header-wrapper-inner">
            <div class="mobile-header-top">
                <div class="mobile-header-logo">
                    <a href="<?php echo e(route("home-page")); ?>"><img src="<?php echo e(asset('storage/'.get_settings('logo'))); ?>"
                            alt="logo" /></a>
                </div>
                <div class="mobile-menu-close close-style-wrap close-style-position-inherit">
                    <button class="close-style search-close">
                        <i class="icon-top"></i>
                        <i class="icon-bottom"></i>
                    </button>
                </div>
            </div>
            <div class="mobile-header-content-area">
                <div class="mobile-search search-style-3 mobile-header-border">
                    <form action="#">
                        <input type="text" placeholder="Search for items…" />
                        <button type="submit"><i class="fi-rs-search"></i></button>
                    </form>
                </div>
                <div class="mobile-menu-wrap mobile-header-border">
                    <!-- mobile menu start -->
                    <nav>
                        <ul class="mobile-menu font-heading">
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(route('home-page')); ?>">Home</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(route('shop-page')); ?>">Shop</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(route('cart-page')); ?>">Cart</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="<?php echo e(route('blog.page')); ?>">Blog</a>
                            </li>
                        </ul>
                    </nav>
                    <!-- mobile menu end -->
                </div>
                <div class="mobile-header-info-wrap">
                    <div class="single-mobile-header-info">
                        <a href="page-contact.html"><i class="fi-rs-marker"></i> Our location </a>
                    </div>
                    <div class="single-mobile-header-info">
                        <a href="page-login.html"><i class="fi-rs-user"></i>Log In / Sign Up </a>
                    </div>
                    <div class="single-mobile-header-info">
                        <a href="#"><i class="fi-rs-headphones"></i>(+01) - 2345 - 6789 </a>
                    </div>
                </div>
                <div class="mobile-social-icon mb-50">
                    <h6 class="mb-15">Follow Us</h6>
                    <a href="#"><img
                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-facebook-white.svg"
                            alt="" /></a>
                    <a href="#"><img
                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-twitter-white.svg"
                            alt="" /></a>
                    <a href="#"><img
                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-instagram-white.svg"
                            alt="" /></a>
                    <a href="#"><img
                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-pinterest-white.svg"
                            alt="" /></a>
                    <a href="#"><img
                            src="<?php echo e(asset('frontend')); ?>/assets/imgs/theme/icons/icon-youtube-white.svg"
                            alt="" /></a>
                </div>
            </div>
        </div>
    </div>
    <!--End header-->
<?php /**PATH C:\lvnpp\Final-Ecomm\resources\views/frontend/header.blade.php ENDPATH**/ ?>