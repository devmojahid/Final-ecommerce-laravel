<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payemnt Success</title>
</head>
<body>
    
    <?php $__currentLoopData = $pament; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h1><?php echo e($paymentman->cus_name); ?></h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</html>
<?php /**PATH C:\lvnpp\Final-Ecomm\resources\views/frontend/payment-success.blade.php ENDPATH**/ ?>