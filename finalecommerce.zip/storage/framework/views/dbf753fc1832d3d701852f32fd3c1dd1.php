<?php $__env->startSection("content"); ?>
 <div class="container m-5">
    <div class="row">
        <div class="col-md-6" style="margin:0 auto;">
            <h1>Order Successfully placed</h1>
            <h2 style="color:blue; font:bold; font-size:30px">Hi <?php echo e($data[0]["cus_name"]); ?></h2>
            <p>Thank you for your order. Your order has been placed successfully. You will receive an email confirmation shortly.</p>
        </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lvnpp\Final-Ecomm\resources\views/frontend/order_success.blade.php ENDPATH**/ ?>