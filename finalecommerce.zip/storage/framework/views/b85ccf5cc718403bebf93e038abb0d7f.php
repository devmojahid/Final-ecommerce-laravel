<?php $__env->startSection('admin_content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Product/</span>Update Product</h4>


        <form action="<?php echo e(route('product.update',$product->slug)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Product Information</h5>
                        </div>
                        <div class="card-body">
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Name</label>
                                <div class="col-sm-10">
                                    <input type="text" value="<?php echo e($product->name); ?>" name="name" class="form-control" id="basic-default-name"
                                        placeholder="Product Name">
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label for="defaultInput" class="col-sm-2 col-form-label">Category</label>
                                <div class="col-sm-10">
                                    <select name="category_id" id="defaultSelect" class="form-select">
                                        <option value=" ">Category select</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($product->category_id ==$category->id ): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label for="defaultInput" class="col-sm-2 col-form-label">Brand</label>
                                <div class="col-sm-10">
                                    <select name="brand_id" id="defaultSelect" class="form-select">
                                        <option value=" ">Brand select</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($product->brand_id ==$brand->id ): ?> selected <?php endif; ?> value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label for="defaultInput" class="col-sm-2 col-form-label">Color</label>
                                <div class="col-sm-10">
                                    <select name="color_id" id="defaultSelect" class="form-select">
                                        <option value=" ">Color select</option>
                                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if($product->color_id ==$color->id ): ?> selected <?php endif; ?> value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            
                            <div class="mb-3 row">
                                <label for="html5-number-input" class="col-md-2 col-form-label">weight</label>
                                <div class="col-md-10">
                                    <input name="weight" value="<?php echo e($product->weight); ?>" class="form-control" type="number" id="html5-number-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Barcode</label>
                                <div class="col-sm-10">
                                    <input type="text" name="barcode" value="<?php echo e($product->barcode); ?>" class="form-control" id="basic-default-name"
                                        placeholder="Barcode">
                                </div>
                            </div>

                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Product Images</h5>
                        </div>
                        <div class="card-body">
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Thumbnail</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="thumbnail" type="file" id="formFile">
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Gallery</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="photos[]" type="file" id="formFile" multiple>
                                </div>
                            </div>

                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Product Video & Audio</h5>
                        </div>
                        <div class="card-body">
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Video</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="product_video_link" type="url"
                                    value="<?php echo e($product->product_video_link); ?>" id="html5-url-input">
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Audio</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="product_audio_link" type="url"
                                    value="<?php echo e($product->product_audio_link); ?>" id="html5-url-input">
                                </div>
                            </div>

                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Product price + stock</h5>
                        </div>
                        <div class="card-body">
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Price</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="price" type="number" value="<?php echo e($product->price); ?>"
                                        id="html5-number-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Discount Type</label>
                                <div class="col-sm-10">
                                    <select name="discount_type" id="defaultSelect" class="form-select">
                                        <option value="flat">Flat</option>
                                        <option value="percent">Percent</option>
                                    </select>
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Discount</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="discount" type="number" value="<?php echo e($product->discount); ?>"
                                        id="html5-number-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Discount Start</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="discount_start" type="datetime-local"
                                    value="<?php echo e($product->discount_start); ?>" id="html5-datetime-local-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Discount End</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="discount_end" type="datetime-local"
                                    value="<?php echo e($product->discount_end); ?>" id="html5-datetime-local-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Sku</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="sku" type="text" value="<?php echo e($product->sku); ?>"
                                        id="html5-text-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Stock</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="number" name="stock" value="<?php echo e($product->stock); ?>"
                                        id="html5-number-input">
                                </div>
                            </div>


                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Product Description</h5>
                        </div>
                        <div class="card-body">
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Summary</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" rows="5" name="summary" type="text" placeholder="Summary"
                                        id="html5-number-input"><?php echo e($product->summary); ?></textarea>
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Description</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control tinymce-editor" rows="10" name="description" type="text" placeholder="Description"
                                        id="html5-number-input"><?php echo e($product->description); ?></textarea>
                                </div>
                            </div>

                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">SEO Meta Tags</h5>
                        </div>
                        <div class="card-body">
                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Meta Title</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="meta_title" type="text"
                                        placeholder="Meta Title" value="<?php echo e($product->meta_title); ?>" id="html5-number-input">
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Meta Description</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control tinymce-editor" rows="10" name="meta_description" type="text" placeholder="Meta Description"
                                        id="html5-number-input"><?php echo e($product->meta_description); ?></textarea>
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Meta Keywords</label>
                                <div class="col-sm-10">
                                    <input class="form-control" name="meta_keywords" type="text"
                                        placeholder="Meta Title" value="<?php echo e($product->meta_keywords); ?>" id="html5-number-input">
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
                <div class="col-md-4">
                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Shipping Configuration</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-6 col-form-label" for="basic-default-name">free_shipping</label>
                                <div class="col-sm-6">
                                    <input name="free_shipping" class="form-check-input" type="checkbox"
                                        id="flexSwitchCheckChecked" value="yes" >
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Vat Tax</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Vat</label>
                                <div class="col-sm-10">
                                    <input name="vat" class="form-control" value="<?php echo e($product->vat); ?>" type="number"
                                        id="flexSwitchCheckChecked">
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Tax</label>
                                <div class="col-sm-10">
                                    <input name="tax" class="form-control" value="<?php echo e($product->tax); ?>" type="number"
                                        id="flexSwitchCheckChecked">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Featured</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-4 col-form-label" for="basic-default-name">Status</label>
                                <div class="col-sm-8">
                                    <input name="featured" class="form-check-input" type="checkbox"
                                        id="flexSwitchCheckChecked" value="yes">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Trending</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-4 col-form-label" for="basic-default-name">Status</label>
                                <div class="col-sm-8">
                                    <input name="trending" class="form-check-input" type="checkbox"
                                        id="flexSwitchCheckChecked" value="yes">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Best Rated</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-4 col-form-label" for="basic-default-name">Status</label>
                                <div class="col-sm-8">
                                    <input name="best_rated" class="form-check-input" type="checkbox"
                                        id="flexSwitchCheckChecked" value="yes">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Hot New</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-4 col-form-label" for="basic-default-name">Status</label>
                                <div class="col-sm-8">
                                    <input name="hot_new" class="form-check-input" type="checkbox"
                                        id="flexSwitchCheckChecked" value="yes">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Special Offer</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-4 col-form-label" for="basic-default-name">Status</label>
                                <div class="col-sm-8">
                                    <input name="special_offer" class="form-check-input" type="checkbox"
                                        id="flexSwitchCheckChecked" value="yes">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card mb-4">
                        <div class="card-header border-bottom mb-3">
                            <h5 class="mb-0">Special Deal</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <label class="col-sm-4 col-form-label" for="basic-default-name">Status</label>
                                <div class="col-sm-8">
                                    <input name="special_deal" class="form-check-input" type="checkbox"
                                        id="flexSwitchCheckChecked" value="yes">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
<script type="text/javascript">
    tinymce.init({
    selector: 'textarea.tinymce-editor',
    height: 400,
    menubar: true,
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.parsial.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\lvnpp\Final-Ecomm\resources\views/admin/products/product/edit.blade.php ENDPATH**/ ?>